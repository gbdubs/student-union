import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;


public class NewsPageGenerator {

	public static void main(String[] args){
		File input = new File("data/template.txt");
		Scanner scan;
		try {
			scan = new Scanner(input);
		} catch (FileNotFoundException e1) {
			System.err.println("GENERAL HTML TEMPLATE NOT FOUND");
			return;
		}
		
		File output = new File("index.html");
		try {
			PrintWriter pw = new PrintWriter(output);
			
			while (scan.hasNextLine()){
				String line = scan.nextLine();
				if (line.contains("[NEWS]")){
					pw.println(getAllNews());
				} else {
					pw.println(line);
				}
			}
			scan.close();
			pw.close();
		} catch (FileNotFoundException e) {
			System.out.println("ERROR IN PRINTING INDEX.HTML");
		}
	}
	
	public static String getAllNews(){
		String results = "";
		List<String> allStoryPaths = getAllFilePathsInFolder("data/stories");
		Collections.reverse(allStoryPaths);
		for (String path : allStoryPaths){
			results += getNewsStory("data/stories/" + path) + "\n";
		}
		return results;
	}
	
	public static String getNewsStory(String fileName){
		File f = new File(fileName);
		Scanner scan;
		try {
			scan = new Scanner(f);
		} catch (FileNotFoundException e) {
			return "";
		}
		
		String date = scan.nextLine();
		String title = scan.nextLine();
		String body = scan.nextLine();
		String img = scan.hasNextLine() ? scan.nextLine() : null;
		
		scan.close();
		
		String result = "<div class=\"news-item\">\n";
		if (img != null){
			result += "\t<img src=\"data/img/" + img + "\"/>\n";
		}	
		result = result
				+ "\t<h5 class=\"bg-brandeis-blue-0 txt-brandeis-white\">" + title + "</h5>\n"
				+ "\t<h6 class=\"bg-brandeis-blue-1 txt-brandeis-white\">" + date + "</h6>\n"
				+ "\t<p>" + body + "</p>\n"
				+ "</div>\n";
		return result;
	}
	
	
	public static List<String> getAllFilePathsInFolder(String folderName){	
		
		File folder = new File(folderName);
		File[] listOfFiles = folder.listFiles();

		List<String> paths = new ArrayList<String>();
		
	    for (int i = 0; i < listOfFiles.length; i++) {
	        if (listOfFiles[i].isFile()) {
	        	if (!listOfFiles[i].isHidden()){
	        		paths.add(listOfFiles[i].getName());
	        	}
	        }
	    }
	    
	    return paths;
	}
	
}
